<?php
$conn=mysql_connect("localhost","root","") or die("SERVER NOT FOUND!!");
mysql_select_db("nrd")or die("Database not found!!");
?>