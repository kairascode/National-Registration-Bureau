<?php
$conn=mysql_connect("localhost","root","3445") or die("SERVER NOT FOUND!!");
mysql_select_db("nrd")or die("Database not found!!");
?>