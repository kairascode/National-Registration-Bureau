<html>
<p align="center" bgcolor="blue"><font color="#561493" type="bold" size="15">NATIONAL REGISTRATION BUREAU</p></font>
<p align="center"> <font color="#561493" type="bold" size="4">Sajiri Version 1.0.0 &copy2016</p></p></font>
<?php
$today=date('y:m:d');
$new= date('l,F d,Y',strtotime($today));
//$time= new time('h:m:s');
echo"<p align='center'><font color='#664557' style='bold' size=13>$new</font></p>";
?>

