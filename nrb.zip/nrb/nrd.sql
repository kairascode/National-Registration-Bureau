-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 27, 2020 at 10:22 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nrd`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `srno` int(9) NOT NULL,
  `id_no` int(8) NOT NULL,
  `typ` varchar(16) NOT NULL,
  `applicant` varchar(35) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(25) NOT NULL,
  `father` varchar(35) NOT NULL,
  `mother` varchar(35) NOT NULL,
  `phone` int(10) NOT NULL,
  `drecorded` date NOT NULL,
  `dreceived` date NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `srno` (`srno`,`id_no`),
  KEY `typ` (`typ`,`applicant`,`sex`,`dob`,`pob`,`father`,`mother`,`phone`),
  KEY `Date Recorded` (`drecorded`),
  KEY `Date received` (`dreceived`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(7) NOT NULL,
  PRIMARY KEY (`no`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`no`, `username`, `password`) VALUES
(1, 'solder', 'sold123'),
(2, 'alex', 'qwerty1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
